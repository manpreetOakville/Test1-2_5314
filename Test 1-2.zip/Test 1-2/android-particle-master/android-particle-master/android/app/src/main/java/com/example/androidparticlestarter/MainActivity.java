package com.example.androidparticlestarter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.particle.android.sdk.cloud.ParticleCloud;
import io.particle.android.sdk.cloud.ParticleCloudSDK;
import io.particle.android.sdk.cloud.ParticleDevice;
import io.particle.android.sdk.cloud.ParticleEvent;
import io.particle.android.sdk.cloud.ParticleEventHandler;
import io.particle.android.sdk.cloud.exceptions.ParticleCloudException;
import io.particle.android.sdk.utils.Async;

public class MainActivity extends AppCompatActivity {
    // MARK: Debug info
    private final String TAG="";

    EditText colorA, colorB, colorC, colorD;
    String text;
    String level;
    TextView results;
    String value1, value2, value3, value4;
    String text2;
    Button playAgain;

    // MARK: Particle Account Info
    private final String PARTICLE_USERNAME = "manpreet@gmail.com";
    private final String PARTICLE_PASSWORD = "Nimarjot7";

    // MARK: Particle device-specific info
    private final String DEVICE_ID = "38002d001e45273330043435";

    // MARK: Particle Publish / Subscribe variables
    private long subscriptionId;

    // MARK: Particle device
    private ParticleDevice mDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        colorA = findViewById(R.id.colorA);
        colorB = findViewById(R.id.colorB);
        colorC = findViewById(R.id.colorC);
        colorD = findViewById(R.id.colorD);
        results = findViewById(R.id.results);
        playAgain = findViewById(R.id.playAgain);


        level = getIntent().getStringExtra("level");
        Toast.makeText(getApplicationContext(),"Level : " +level, Toast.LENGTH_SHORT).show();

        // 1. Initialize your connection to the Particle API
        ParticleCloudSDK.init(this.getApplicationContext());

        // 2. Setup your device variable
        getDeviceFromCloud();
        //ParticleCloudSDK.getCloud().
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {


                try {
                    subscriptionId = ParticleCloudSDK.getCloud().subscribeToAllEvents("broadcastMessage", new ParticleEventHandler() {

                        @Override
                        public void onEventError(Exception e) {
                        }
                        @Override
                        public void onEvent(String eventName, ParticleEvent particleEvent) {
                            text = particleEvent.dataPayload;
                            Log.d(" First Event  = " + eventName, particleEvent.dataPayload);
                            Log.d("Second Event = " + eventName, text);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return -1;
            }

            @Override
            public void onSuccess(Object o) {

                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });

    }

    public void playAgain(View v)
    {
        colorA.setText("");
        colorB.setText("");
        colorC.setText("");
        colorD.setText("");
        results.setText("");
        text = null;
        text2 = null;
        Toast.makeText(getApplicationContext(),"Please click on Particle device's button to start ", Toast.LENGTH_SHORT).show();
        //finish();
        finishAffinity();
        startActivity(new Intent(getApplicationContext(), ChooseLevelActivity.class));
    }

    public void checkResult(View v)
    {
        value1 = colorA.getText().toString();
        value2 = colorB.getText().toString();
        value3 = colorC.getText().toString();
        value4 = colorD.getText().toString();
        text2 = value1+value2+value3+value4;
        Toast.makeText(getApplicationContext(),text2 +"Text@2" + text, Toast.LENGTH_SHORT).show();

        if(text == null)
        {
            Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

                @Override
                public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {


                    try {
                        subscriptionId = ParticleCloudSDK.getCloud().subscribeToAllEvents("broadcastMessage", new ParticleEventHandler() {

                            @Override
                            public void onEventError(Exception e) {
                            }
                            @Override
                            public void onEvent(String eventName, ParticleEvent particleEvent) {
                                text = particleEvent.dataPayload;
                                Log.d("First Event = " + eventName, particleEvent.dataPayload);
                                Log.d("Second Event = " + eventName, text);
                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    return -1;
                }

                @Override
                public void onSuccess(Object o) {

                    Log.d(TAG, "Successfully got device from Cloud");
                }

                @Override
                public void onFailure(ParticleCloudException exception) {
                    Log.d(TAG, exception.getBestMessage());
                }
            });

        }
        //result.setText("text "+text+ "     text2"+text2);

        if (text != null && text2!= null && !text2.isEmpty())

            if (text.equalsIgnoreCase(text2)) {
                Toast.makeText(getApplicationContext(),"Won", Toast.LENGTH_SHORT).show();
                //Log.d("WON = ", "WON");
                result.setText("YOU WIN");
                playAgain.setEnabled(true);

            } else {
                Toast.makeText(getApplicationContext(),"Lose", Toast.LENGTH_SHORT).show();

                result.setText("YOU LOSE");
                playAgain.setEnabled(true);

            }

    }

    /**
     * Custom function to connect to the Particle Cloud and get the device
     */
    public void getDeviceFromCloud() {
        // This function runs in the background
        // It tries to connect to the Particle Cloud and get your device
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                particleCloud.logIn(PARTICLE_USERNAME, PARTICLE_PASSWORD);
                mDevice = particleCloud.getDevice(DEVICE_ID);


                List<String> param = new ArrayList<String>();
                param.add(level);
                try {

                    mDevice.callFunction("Game",param);
                }
                catch(Exception e)
                {
                    Log.e("logg", e.toString());
                }

                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }

}

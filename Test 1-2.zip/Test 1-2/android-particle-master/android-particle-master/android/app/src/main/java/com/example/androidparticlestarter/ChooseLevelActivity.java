package com.example.androidparticlestarter;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ChooseLevelActivity extends AppCompatActivity {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    TextView Name;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_level);
        Name = findViewById(R.id.userName);
        pref = getApplicationContext().getSharedPreferences("Name");
        editor = pref.edit();
        String name = pref.getString("Name", null);
        if (name != null)
        {
            name.setText("Hello! "+ Name);
        }

        else
        {
            Toast.makeText(this, " Name Not Found ", Toast.LENGTH_SHORT).show();
        }
    }

    public void levelEasy(View view)
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra("level", "Easy");
        finish();
        startActivity(intent);
    }

    public void levelHard(View view)
    {

        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.putExtra("level", "Hard");
        finish();
        startActivity(intent);
    }
}
